import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myapp1comp1',
  templateUrl: './myapp1comp1.component.html',
  styleUrls: ['./myapp1comp1.component.css']
})
export class Myapp1comp1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
