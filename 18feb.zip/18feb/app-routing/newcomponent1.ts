import { Component } from '@angular/core';

@Component({
  selector: 'app-new',
  template: `<h2>info</h2>`
})
export class NewComponent1 { }