package com.cts.hibernate;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.cts.model.Employee;

public class Test {
public static void main(String args[])
{
	Configuration configuration = new Configuration().configure();
    StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
    SessionFactory factory = configuration.buildSessionFactory(builder.build());
    Session session = factory.openSession();
    //Employee emp1=new Employee(505,"abhi1","manager1");
    //Employee emp2=new Employee(502,"bindhu","manager");
    //session.beginTransaction();
    //session.save(emp1);
   // session.save(emp2);
   // session.getTransaction().commit();
   /* Criteria cri=session.createCriteria(Employee.class);
    cri.addOrder(Order.desc("employeeId"));
    List res=cri.list();
    System.out.println(res);*/
    /*Criteria cri=session.createCriteria(Employee.class);
    cri.add(Restrictions.like("empname", "a%"));
    List dl=cri.list();
    System.out.println(dl);*/
    Criteria cri=session.createCriteria(Employee.class);
 cri.add(Restrictions.eq("empdesig", "manager"));
 cri.addOrder(Order.desc("employeeId"));
 List res=cri.list();
 System.out.println(res);
    
    
    
   
    
}
}
