package com.cts.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Employee implements Serializable {
@Id
private int employeeId;
@Column(name="employeeName")
private String empname;
@Column(name="employeeDesig")
private String empdesig;
public Employee(int employeeId, String empname, String empdesig) {

	this.employeeId = employeeId;
	this.empname = empname;
	this.empdesig = empdesig;
}
public Employee() {
	
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public String getEmpdesig() {
	return empdesig;
}
public void setEmpdesig(String empdesig) {
	this.empdesig = empdesig;
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", empname=" + empname + ", empdesig=" + empdesig + "]";
}

}
