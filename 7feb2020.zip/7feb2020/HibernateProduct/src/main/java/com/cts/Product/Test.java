package com.cts.Product;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;

import com.cts.Model.Cart;
import com.cts.Model.CartItem;


public class Test {

	public static void main(String args[])
	{
		Configuration configuration = new Configuration().configure();
	    StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
	    SessionFactory factory = configuration.buildSessionFactory(builder.build());
	    Session session = factory.openSession();
	   /* Cart cart=new Cart();
	    cart.setQuantity(100);
	    CartItem cartitem=new CartItem();
	    cartitem.setDescription("recent product with max offers");
	    session.beginTransaction();
	    session.save(cartitem);
	    cart.setCartitem(cartitem);
	    session.save(cart);
	    session.getTransaction().commit();*/
	   /* //adding data into tables
	    Cart cart=new Cart();
	    cart.setQuantity(8760);
	    CartItem cartitem=new CartItem();
	    cartitem.setDescription("item6");
	    session.beginTransaction();
	    session.save(cartitem);
	    cart.setCartitem(cartitem);
	    session.save(cart);
	    session.getTransaction().commit();*/
	   /*//error
	    Criteria cri=session.createCriteria(Cart.class);
	   cri.addOrder(Order.desc("cartId"));
	   List res=cri.list();
	   Iterator i=res.iterator();
	   while(i.hasNext())
	   {
		Object[] h=(Object[])i.next();
		   System.out.println(h[0]+"---"+h[1]+"-----"+h[3]);
	   }*/
	   
}
}