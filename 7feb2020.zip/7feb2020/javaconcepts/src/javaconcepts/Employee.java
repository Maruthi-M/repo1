package javaconcepts;

import java.util.Scanner;

public class Employee {
	public static void main(String args[])
	{
	int age;
	Scanner sc=new Scanner(System.in);
	int value=sc.nextInt();
	}
		
}

