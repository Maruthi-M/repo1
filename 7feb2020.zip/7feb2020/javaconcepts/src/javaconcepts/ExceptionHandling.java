package javaconcepts;

public class ExceptionHandling {
	public static void main(String args[])
	{
		/*int a=90,b=8,c=0;
		c=a/b;
		System.out.println(c);*/
		//Exception in thread "main" java.lang.ArithmeticException: / by zero----handled by jvm (unchecked exceptions)
		/*int a=20,b=0,c;
		c=a/b;
		System.out.println(c);*/
		//handling unchecked exceptions---console::message/ by zero final block
		int a=20,b=0,c;
		try
		{
			c=a/b;
			System.out.println(c);
		}
		catch(Exception e)
		{
			System.out.println("message"+e.getMessage());
		}
		finally
		{
			System.out.println("final block");
		}
		
		
		
	}
	

}
