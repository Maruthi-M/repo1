package javaconcepts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Streams {
	public static void main(String args[])
	{
		/*List list=new ArrayList();
		list.add("java");
		list.add("c");
		list.add("c++");
		list.add("js");
		Stream<String> str=list.stream();
		str.forEach(System.out::println);*/
		/*String name[]={"abhi","bhanu","chandhu","durga","eswar","feroz"};
		Stream<String> ss=Arrays.stream(name,1,4);
		ss.forEach(System.out::println);*/
		//Stream<string> streamgenerated=StreamGenerate()
		/*Stream<String> streamBuilder =
				 Stream.<String>builder().add("amazon").add("bluetooth").add("cardreader").add("digitalworld").build();
	streamBuilder.forEach(System.out::println);*/
		/*Stream<Integer> streamIterated = Stream.iterate(10, n -> n + 2).limit(2);
		streamIterated.forEach(System.out::print);*/
		/*Stream<String> streamGenerated =
				  Stream.generate(() -> "value").limit(5);
		streamGenerated.forEach(System.out::println);*/
		/*List list=new ArrayList();
		list.add("java");
		list.add("c");
		list.add("c++");
		list.add("js");
		Stream<List> streamGenerated =
				  Stream.generate(() -> list).limit(2);
		streamGenerated.forEach(System.out::println);*/
		/*TreeSet<String> s=new TreeSet<>();
		s.add("Abstraction");
		s.add("Encapsulation");
		s.add("Inheritance");
		s.add("polymorphism");
		Set data=s.stream().collect(Collectors.toSet());
		System.out.println(data);*/
		List li=Arrays.asList("emp1","madhu",109877,"chennai");
		Object empdata=li.stream().collect(Collectors.toList());
		System.out.println(empdata);
		for(Object o:(List<Object>)empdata)
		{
			System.out.println(o);
		}
	}

}
