package com.cts.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Model.Buyer;
import com.cts.Service.BuyerService;

@RestController
@CrossOrigin(origins = "*")
public class BuyerController {
	@Autowired 
	public BuyerService buyerservice;
	//getting all buyers
	@GetMapping("getAllBuyers")
	public List<Buyer> getAllBuyers()
	{
		return buyerservice.getAllbuyers();
	}
	//adding buyer
		@RequestMapping(value="addBuyer" ,method=RequestMethod.POST,produces="application/json")
		public Buyer addBuyer(@RequestBody Buyer buyer)
		{
			return buyerservice.addbuyer(buyer);
			
		}

}
