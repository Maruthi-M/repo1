package com.cts.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Model.PurchaseHistory;
import com.cts.Model.ShoppingCart;
import com.cts.Model.Transactions;
import com.cts.Service.ShoppingCartService;


@RestController
@CrossOrigin(origins = "*")
public class ShoppingCartController {
	@Autowired 
	public ShoppingCartService cartservice;
		//get cart items by id
		@RequestMapping("getCartItemsById/{bid}")
		public List<ShoppingCart> getCartItemsById(@PathVariable("bid") int bid)
		{
			
			return cartservice.getCartItemsById(bid);
			
		}
		//adding cart item
		@RequestMapping(value = "addCartItem/{buyerId}", method = RequestMethod.POST,produces = "application/json") 
		public String addCartItem(@RequestBody ShoppingCart cart,@PathVariable("buyerId") int bid)
		{
			return cartservice.addCartItem(cart,bid);
			
		}
		//delete cart item by cartId
		@DeleteMapping("deleteCartItem/{id}")
		public void deleteCartItem(@PathVariable("id") int id) {
			cartservice.deleteCartItem(id);

		}
		//deleting cart items by buyer id
		@RequestMapping("deleteCartItemByBuyerId/{bid}")
		public void deleteCartItembyid(@PathVariable("bid") int id) {
			cartservice.deleteCartItembyid(id);

		}
		//update cart item
		@PutMapping("updatecart/{cartId}")
		public ShoppingCart updatecart(@PathVariable("cartId") int cid,@RequestBody ShoppingCart cart)
		{
			return cartservice.updatecart(cid,cart);
		
		}
		//checkout
		@PostMapping("checkout/{buyerId}")
		public ShoppingCart checkout(@PathVariable("buyerId") int bid,@RequestBody Transactions transaction)
		{
			return cartservice.checkout(bid,transaction);
		}
		//purchase history
		@GetMapping("purchasehistory/{buyerId}")
		public List<PurchaseHistory> purchasehistory(@PathVariable("buyerId") int bid)
		{
			
			return cartservice.purchasehistory(bid);
			
		}
		
		
}
