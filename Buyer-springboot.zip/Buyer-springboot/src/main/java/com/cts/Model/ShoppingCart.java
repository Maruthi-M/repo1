package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="shopping_cart")
public class ShoppingCart implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cartId;
	private int numberOfItems;
	private int productId;
	private float price;
	private String productName;
	@ManyToOne
	@JoinColumn(name="buyer_key")
	private Buyer buyerId;
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Buyer getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Buyer buyerId) {
		this.buyerId = buyerId;
	}
	public ShoppingCart(int cartId, int numberOfItems, int productId, float price, String productName, Buyer buyerId) {
		super();
		this.cartId = cartId;
		this.numberOfItems = numberOfItems;
		this.productId = productId;
		this.price = price;
		this.productName = productName;
		this.buyerId = buyerId;
	}
	public ShoppingCart() {
		super();
	}
	
	
	
	

}
