package com.cts.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.Model.PurchaseHistory;
import com.cts.Model.ShoppingCart;

@Repository
public interface PurchaseDao extends JpaRepository<PurchaseHistory,Integer>{
	@Query(value="SELECT * FROM purchase_history where buyer_key =:bid",nativeQuery = true)
	public List<PurchaseHistory> purchasehistorybybuyerid(int bid);

	
}
