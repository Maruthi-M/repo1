package com.cts.Seller.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Seller.Model.Seller;
import com.cts.Seller.Repository.SellerRepository;

@Service
public class SellerService {
@Autowired SellerRepository sellerdao;
//getting all sellers
public List<Seller> getAllSellers() {
	return sellerdao.findAll();
}
//seller by id
public Optional<Seller> sellerById(int bid) {
	
	return sellerdao.findById(bid);
}
//seller by id
public Optional<Seller> getSellerById(int sid) {
	
	return sellerdao.findById(sid);
}
//adding seller
public Seller addSeller(Seller seller){
	
	return sellerdao.save(seller);
}
	
}
