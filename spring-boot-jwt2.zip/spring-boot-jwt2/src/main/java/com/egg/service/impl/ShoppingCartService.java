package com.egg.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.egg.dao.BuyerDao;
import com.egg.dao.PurchaseDao;
import com.egg.dao.ShoppingCartDao;
import com.egg.dao.TransactionDao;
import com.egg.model.Buyer;
import com.egg.model.PurchaseHistory;
import com.egg.model.ShoppingCart;
import com.egg.model.Transactions;


@Service
public class ShoppingCartService {
	@Autowired 
	private ShoppingCartDao cartdao;
	@Autowired
	private BuyerDao buyerdao;
	@Autowired
	private TransactionDao trandao;
	@Autowired
	private PurchaseDao purchasedao;
	//get cart item by buyer id
	public List<ShoppingCart> getCartItemsById(int bid) {
		
		return cartdao.getCartItemsById(bid);
	}
	//adding cart item
	public String addCartItem(ShoppingCart cart, int bid) {
		Buyer b=buyerdao.getOne(bid);
		cart.setBuyerId(b);
		cartdao.save(cart);
		return "\"added to cart\"";
		 
		
		
	}
	//delete cart item by cartId
	public void deleteCartItem(int id) {
		cartdao.deleteById(id);
		
	}
	//deleting cart items by buyer id--empty cart
	public void deleteCartItembyid(int id) {
		cartdao.deleteCartItembyid(id);
	}
	//updating an cart by cart id
	public ShoppingCart updatecart(int cid, ShoppingCart cart) {
		ShoppingCart c=cartdao.getOne(cid);
		int numberofitems=cart.getNumberOfItems();
		c.setNumberOfItems(numberofitems);
		return cartdao.save(c);
		//return "{\"updated\":1}";
	}
	//checkout by buyerId
	public ShoppingCart checkout(int bid, Transactions transaction) {
		PurchaseHistory purchase=null;
		Buyer b=buyerdao.getOne(bid);
		transaction.setBuyerId(b);
		//transaction.setTransactionType("debit card");
		//transaction.getTransactionType();
		//transaction.getTransactionnumber();
		 trandao.save(transaction);
		List<ShoppingCart> getAllItems=cartdao.getAllItems(bid);
		for(ShoppingCart cart:getAllItems)
		{
			int n=cart.getNumberOfItems();
			for(int i=0;i<n;i++)
			{
			purchase=new PurchaseHistory();
			purchase.setBuyerId(b);
			purchase.setProductId(cart.getProductId());
			purchase.setProductprice(cart.getPrice());
			//purchase.setItem(cart.getItem());
			purchase.setNumberOfItems(i);
			//purchase.setNumberOfItems(cart.getNumberofitems());
			cartdao.deleteCartItembyid(bid);
			purchasedao.save(purchase);
	
			}
		}
		
		 return null;
	}
	public List<PurchaseHistory> purchasehistory(int bid) {
		
		return purchasedao.purchasehistorybybuyerid(bid);
	}
	

}
