package com.egg.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.CategoryRepository;
import com.egg.dao.ProductRepository;
import com.egg.dao.SellerRepository;
import com.egg.dao.SubCategoryRepository;
import com.egg.model.Category;
import com.egg.model.Product;
import com.egg.model.Seller;
import com.egg.model.SubCategory;


@Service
public class ProductService {
	@Autowired 
	private ProductRepository productdao;
	@Autowired 
	private SellerRepository sellerdao;
	@Autowired 
	private CategoryRepository categorydao;
	@Autowired 
	private SubCategoryRepository subcategorydao;
	//adding product
	public String addProduct(Product product, int sid) {
	Seller s=sellerdao.getOne(sid);
	product.setSeller(s);
	 productdao.save(product);
	return "\"product added\"";
	//view products by seller id	
	}
	public List<Product> viewproducts(int sid) {
	
		return productdao.viewproducts(sid);
	}
	//delete product by sellerId and productId
	public int deleteproduct(int sid, int pid) {
		
		return productdao.deleteproduct(sid,pid);
	}
	//update product by productId---productname,manufacture,model,numofproducts,
	public Product updateproduct(int pid, Product product) {
		Product p=productdao.getOne(pid);
		String pn=product.getProductName(); 
		String manufacture=product.getManufacture();
		String model=product.getModel();
		int n=product.getNumberOfProducts();
		p.setProductName(pn);
		p.setManufacture(manufacture);
		p.setModel(model);
		p.setNumberOfProducts(n);
		return productdao.save(p);
	}
	//getting category item by id
	public Optional<Category> getcategoryitem(int id) {
		
		return categorydao.findById(id);
	}
	//getting subcategory item by id
	public Optional<SubCategory> getsubcategoryitem(int id) {
		
		return subcategorydao.findById(id);
	}
	//searching product by name
	public List<Product> getproductbyname(String name) {
		
		return productdao.getproductbyname(name);
	}
	
	/*public List<Product> getProduct(int pid, int sid) {
		
		return productdao.getProduct(pid,sid);
	}*/
	

}
