package com.cts;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SpringSecurity {
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String index()
	{
		return "index";
	}
	@RequestMapping(value="/admin",method=RequestMethod.GET)
	public String admin(Model m)
	{
		m.addAttribute("msg","welcome admin");
		return "admin";
	}
	@RequestMapping(value="/manager",method=RequestMethod.GET)
	public String manager(Model m1)
	{
		m1.addAttribute("msg","welcome manager");
		return "manager";
	}

}
