export class modelproduct
{
    productId: number;
    productName: String;
    manufacture: String;
    model: String;
    price:number;
    numberOfProducts:number;
    description:String;
    seller:number;
 
}
/**private int productId;
	private String productName;
	private String manufacture;
	private String model;
	private float price;
	private int numberOfProducts; */