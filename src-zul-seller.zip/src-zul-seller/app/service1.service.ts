import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from 'rxjs';
import{seller,ApiResponse} from './seller';
import { modelproduct } from './modelproduct';

@Injectable({
  providedIn: 'root'
})
export class Service1Service {
  
  private baseUrl='http://localhost:8989/mentorportal/spring-boot-jwt-seller';


  constructor(private http:HttpClient) { }
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8989/mentorportal/spring-boot-jwt-seller/' + 'token/generate-token', loginPayload);
    
    
  }
 getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addSeller(s:seller):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/addSeller`,s);
  }
  addProduct(product:modelproduct,sid:String):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/addProduct/${sid}`,product);
  }

viewproducts(sid:String):Observable<any>
{
return this.http.get(`${this.baseUrl}/viewproducts/${sid}`);

}
deleteproduct(productId:number,sid:String):Observable<any>
{
return this.http.delete(`${this.baseUrl}/deleteproduct/${sid}/${productId}`);
}
updateproduct(productId:number,product:modelproduct):Observable<any>
{
  return this.http.put(`${this.baseUrl}/updateproduct/${productId}`,product);
}
}




