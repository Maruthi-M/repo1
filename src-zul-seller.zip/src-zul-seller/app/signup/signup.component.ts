import { Component, OnInit } from '@angular/core';
import { Service1Service } from '../service1.service';
import { Router } from '@angular/router';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { seller } from '../seller';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  s:seller=new seller();
//b:buyer=new buyer();
//signupform:FormGroup;
  constructor(private sellerservice:Service1Service,private router:Router) { }
  
  ngOnInit(): void {
    
  }
  onSubmit()
  {
    console.log("seller adding method");
this.sellerservice.addSeller(this.s).subscribe(s=>{this.router.navigate(['addproduct'])});
  
}
}
  /** onSubmit()
  {
console.log("buyer adding method");
this.buyerservice.addBuyer(this.b).subscribe(b=>{
  this.router.navigate(['search']);
  });
  } */


