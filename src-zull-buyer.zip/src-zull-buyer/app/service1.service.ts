import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from 'rxjs';
import{Shoppingcart} from './shoppingcart';
import{buyer, ApiResponse} from './buyer';
import { transactions } from './transactions';
import { purchasehistory } from './purchasehistory';

@Injectable({
  providedIn: 'root'
})
export class Service1Service {
  private baseUrl='http://localhost:8989/mentorportal/spring-boot-jwt-seller';
  
  private baseUrl1='http://localhost:8989/mentorportal/spring-boot-jwt-buyer';

  constructor(private http:HttpClient) { }
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8989/mentorportal/spring-boot-jwt-buyer/' + 'token/generate-token', loginPayload);
  }
  getCartItemsById(bid:String):Observable<any>
  {
    return this.http.get(`${this.baseUrl1}/getCartItemsById/${bid}`);
  }
  getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addCartItem(cart:Shoppingcart,bid:String):Observable<any>
  {
  return this.http.post(`${this.baseUrl1}/addCartItem/${bid}`,cart);
  }
  deleteCartItem(cartId:number) : Observable<any>
  {
    return this.http.delete(`${this.baseUrl1}/deleteCartItem/${cartId}`);
  }
  addBuyer(b:buyer)
  {
return this.http.post(`${this.baseUrl1}/addBuyer`,b);
  }
updatecart(cartId:number,cart:Shoppingcart)
{
  return this.http.put(`${this.baseUrl1}/updatecart/${cartId}`,cart);
}
checkout(trs:transactions,bid:String):Observable<any>
{
  return this.http.post(`${this.baseUrl1}/checkout/${bid}`,trs);
}
purchasehistory(bid:String):Observable<any>
{
  return this.http.get(`${this.baseUrl1}/purchasehistory/${bid}`);
}

}
