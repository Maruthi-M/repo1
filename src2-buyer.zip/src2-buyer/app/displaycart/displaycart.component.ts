import { Component, OnInit } from '@angular/core';

import {Service1Service} from '../service1.service';
import { Shoppingcart } from '../Shoppingcart';
import { Router } from '@angular/router';
import { transactions } from '../transactions';
import { purchasehistory } from '../purchasehistory';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
cartitems:Shoppingcart[];
cart:any;
t:number;
ph:purchasehistory=new purchasehistory();
bid:String=localStorage.getItem("id");
  constructor(private productservice:Service1Service,private router:Router) { }

  ngOnInit(): void {
    if(this.bid)
    {
    this.reload();
  }
  else
  {
    this.router.navigate(['loginbuyer']);
  }
   
   
  }
 /*totalamount(id,price,no)
 {
while(id>0)
{
  this.t=price*2;
  console.log(this.t);
}
 }*/
  reload(){

    this.productservice.getCartItemsById(this.bid).subscribe(cartitems=>this.cartitems=cartitems);

  }
  
  deleteCartItem(v):void
  {
    console.log("delete cart item method");
    this.productservice.deleteCartItem(v).subscribe( () => this.reload());
  }
  onIncre(cid,cart)
  {
    cart.numberOfItems+=1;
    this.productservice.updatecart(cid,cart).subscribe(v=>this.cart=v);
    //this.pservice.updateproduct(i,product).subscribe(v=>this.product=v);
  }
  onDecre(cid,cart)
  {
    cart.numberOfItems-=1;
    this.productservice.updatecart(cid,cart).subscribe(v=>this.cart=v);
  }
  

}
