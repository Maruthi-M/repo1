export class purchasehistory
{
    purchaseId:number;
    numberOfItems:number;
    productId:number;
    productprice:number;
    dateTime:String;
}