import { Component, OnInit } from '@angular/core';
import {Service1Service} from '../service1.service';
  import { Modelproduct } from '../modelproduct';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  productname:String;
  product: Modelproduct[];
  constructor(private searchservice:Service1Service) { }

  ngOnInit(): void {
    this.productname="";
  }
  search()
  {
    console.log(" serach method() invoked");
    //console.log(this.product.productId);
    this.searchservice.getProductByName(this.productname).subscribe(product=>this.product=product);
  }
}
