import { Component, OnInit } from '@angular/core';
import { modelproduct } from '../modelproduct';
import { Service1Service } from '../service1.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
productlist:modelproduct=new modelproduct();
product:any;
sid:String=localStorage.getItem("id");
  constructor(private pservice:Service1Service) { }

  ngOnInit(): void {
  this.reload();
  }
  reload()
  {
    console.log("seller product list");
    this.pservice.viewproducts(this.sid).subscribe(productlist=>this.productlist=productlist);
  }

onDelete(pid)
{
    console.log("delete product by seller id method");
  //this.pservice.deleteproduct(pid).subscribe(productlist=>this.productlist=productlist);
  this.pservice.deleteproduct(pid,this.sid).subscribe(()=>this.reload());
}
onIncre(i,product)
{
  product.numberOfProducts+=1;
console.log("incre v"+i);
this.pservice.updateproduct(i,product).subscribe(v=>this.product=v);
}
onDecre(d,product)
{
  product.numberOfProducts-=1;
  console.log("decre v"+d);
  this.pservice.updateproduct(d,product).subscribe(v=>this.product=v);
}
}
/** ngOnInit(): void {
    console.log("display cart component");
    this.productservice.getCartItemsById().subscribe(cartitems=>this.cartitems=cartitems);
  } */